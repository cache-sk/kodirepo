# plugin.video.rebit.tv

Plugin generuje playlist a EPG pre službu Rebit.tv, pre použitie v IPTV Simple Client.

Proces generovania je relativne pomaly, nakolko sluzba vracia zbytocne velke mnozstvo EPG dat.

Subory su vygenerovne vramci dat pluginu, nastavit spravne hodnoty do IPTV Simple Client je mozne spustenim procesu v nastaveniach.