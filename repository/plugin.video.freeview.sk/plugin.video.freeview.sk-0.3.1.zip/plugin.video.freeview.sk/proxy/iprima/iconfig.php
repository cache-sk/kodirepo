<?
	$CHANNELS = array(
		"prima" => array(
			"https://prima.iprima.cz/",
			"https://api.play-backend.iprima.cz/prehravac/init-embed?_infuse=1&_ts=1583254050717&adKeywords%5B%5D=prima&postrollDisable=false&overlayer=true&siteIdentifier=prima&playerType=player&timeshiftDisabled=true&anonym=false&muted=true&productId=p111013&embed=true"
		),
		"cool" => array(
			"https://cool.iprima.cz/",
			"https://api.play-backend.iprima.cz/prehravac/init-embed?_infuse=1&_ts=1583256537541&adKeywords%5B%5D=cool&postrollDisable=false&overlayer=true&siteIdentifier=cool&playerType=player&timeshiftDisabled=true&anonym=false&muted=true&productId=p111014&embed=true"
		),
		"max" => array(
			"https://max.iprima.cz/",
			"https://api.play-backend.iprima.cz/prehravac/init-embed?_infuse=1&_ts=1583257147557&adKeywords%5B%5D=max&postrollDisable=false&overlayer=true&siteIdentifier=max&playerType=player&timeshiftDisabled=true&anonym=false&muted=true&productId=p111017&embed=true"
		),
		"krimi" => array(
			"https://krimi.iprima.cz/",
			"https://api.play-backend.iprima.cz/prehravac/init-embed?_infuse=1&_ts=1583257230316&adKeywords%5B%5D=krimi&postrollDisable=false&overlayer=true&siteIdentifier=krimi&playerType=player&timeshiftDisabled=true&anonym=false&muted=true&productId=p432829&embed=true"
		),
		"love" => array(
			"https://love.iprima.cz/",
			"https://api.play-backend.iprima.cz/prehravac/init-embed?_infuse=1&_ts=1583257285768&adKeywords%5B%5D=love&postrollDisable=false&overlayer=true&siteIdentifier=love&playerType=player&timeshiftDisabled=true&anonym=false&muted=true&productId=p111016&embed=true"
		),
		"zoom" => array(
			"https://zoom.iprima.cz/",
			"https://api.play-backend.iprima.cz/prehravac/init-embed?_infuse=1&_ts=1583257339894&adKeywords%5B%5D=zoom&postrollDisable=false&overlayer=true&siteIdentifier=zoom&playerType=player&timeshiftDisabled=true&anonym=false&muted=true&productId=p111015&embed=true"
		)
	);
	
	$UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0';
?>