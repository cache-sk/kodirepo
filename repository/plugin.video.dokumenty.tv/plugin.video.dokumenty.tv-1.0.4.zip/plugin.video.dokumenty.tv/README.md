# plugin.video.dokumenty.tv

Kodi plugin pre dokumenty.tv

Vyžaduje: script.module.resolveurl, script.module.urlresolver

Plugin neposkytuje žiaden obsah, je to len simulácia prehliadača verejne dostupnej web stránky. Nie som zodpovedný za obsah, ktorý táto stránka poskytuje.