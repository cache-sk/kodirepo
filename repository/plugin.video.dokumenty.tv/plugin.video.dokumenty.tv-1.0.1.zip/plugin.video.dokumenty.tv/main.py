# -*- coding: utf-8 -*-
# Module: default
# Author: cache
# Created on: 30.4.2019
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import sys
import dokumenty

if __name__ == '__main__':
    dokumenty.router(sys.argv[2][1:])
