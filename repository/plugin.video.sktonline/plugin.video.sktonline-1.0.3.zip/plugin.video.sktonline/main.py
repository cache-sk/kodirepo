# -*- coding: utf-8 -*-
# Module: default
# Author: cache
# Created on: 6.8.2019
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import sys
import sktonline

if __name__ == '__main__':
    sktonline.router(sys.argv[2][1:])
