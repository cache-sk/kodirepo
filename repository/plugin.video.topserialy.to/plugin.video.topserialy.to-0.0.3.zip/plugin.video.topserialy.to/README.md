# plugin.video.topserialy.to

Kodi plugin pre už nefunkčnú stránku topserialy.to.

Vyžadoval: script.module.resolveurl

Plugin neposkytoval žiaden obsah, bola to len simulácia prehliadača verejne dostupnej web stránky. Nie som zodpovedný za obsah, ktorý táto stránka poskytovala.