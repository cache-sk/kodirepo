# plugin.video.topserialy.to
kodi plugin pre topserialy.to
iba nutne funkcne minimum
vyzaduje: script.module.resolveurl
