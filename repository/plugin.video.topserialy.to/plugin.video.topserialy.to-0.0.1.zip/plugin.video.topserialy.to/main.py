# -*- coding: utf-8 -*-
# Module: default
# Author: cache-sk
# Created on: 19.9.2019
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import sys
import topserialy

if __name__ == '__main__':
    topserialy.router(sys.argv[2][1:])
