# -*- coding: utf-8 -*-
# Module: epgprocessor
# Author: cache-sk
# Modified by: cratos38
# License: MIT https://opensource.org/licenses/MIT

import os, re, json
import gzip
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
import xbmc
import xbmcaddon
import xbmcvfs
import traceback
import requests.cookies
from bs4 import BeautifulSoup

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath
    
try:
    import zoneinfo
    TZ = zoneinfo.ZoneInfo("Europe/Bratislava")
    UTC = zoneinfo.ZoneInfo("UTC")
except Exception:
    # Python 2 fallback
    import time
    from datetime import tzinfo

    class FixedOffset(tzinfo):
        def __init__(self, offset_seconds):
            self.offset = timedelta(seconds=offset_seconds)

        def utcoffset(self, dt):
            return self.offset

        def dst(self, dt):
            return timedelta(0)

    offset = -time.timezone
    if time.daylight and time.localtime().tm_isdst:
        offset = -time.altzone

    TZ = FixedOffset(offset)
    UTC = FixedOffset(0)

EPG_URL = 'https://iptv-epg.org/files/epg-cz.xml.gz'
HEADERS={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36'}

_addon = xbmcaddon.Addon()
_addon_path = translatePath(_addon.getAddonInfo('profile'))

try:
    unicode  # Python 2
    PY2 = True
except NameError:
    PY2 = False

def log(msg):
    """Log messages to Kodi log"""
    if PY2:
        try:
            msg = msg.encode('utf-8')
        except:
            pass
    xbmc.log('[FREEVIEW EPG] %s' % msg, xbmc.LOGINFO)

def download_epg():
    """
    Download EPG data from iptv-epg.org
    Returns: Path to downloaded file or None if failed
    """

    log(u'Downloading EPG from: %s' % EPG_URL)
    
    epg_file = os.path.join(_addon_path, 'epg-cz.xml.gz')

    

    try:
        session = requests.Session()
        r = session.get(EPG_URL, headers=HEADERS, stream=True, allow_redirects=True)
        r.raise_for_status()

        with open(epg_file, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
    
        log(u'EPG downloaded successfully: %s' % epg_file)
        return epg_file
    except Exception as e:
        log(u'ERROR downloading EPG: %s' % str(e))
        return None

def extract_epg(gz_file):
    """
    Extract gzipped EPG file
    Returns: Path to extracted XML or None if failed
    """
    try:
        xml_file = gz_file.replace('.gz', '')
        
        log(u'Extracting EPG: %s -> %s' % (gz_file, xml_file))
        
        with gzip.open(gz_file, 'rb') as f_in:
            with open(xml_file, 'wb') as f_out:
                f_out.write(f_in.read())
        
        log(u'EPG extracted successfully')
        return xml_file
        
    except Exception as e:
        log(u'ERROR extracting EPG: %s' % str(e))
        return None

def parse_epg(channel_ids, xml_file, xml_text=None):
    """
    Parse EPG XML and return programme data
    Returns: Dictionary of {channel_id: [programmes]}
    """
    try:
        if xml_text is None:
            log(u'Parsing EPG XML: %s' % xml_file)
            tree = ET.parse(xml_file)
            root = tree.getroot()
        else:
            log(u'Parsing xml_text')
            root = ET.fromstring(xml_text)
            tree = ET.ElementTree(root)        
            
        epg_data = {i: [] for i in channel_ids}
        
        # Parse programmes
        for programme in root.findall('programme'):
            channel = programme.get('channel')
            if channel in channel_ids:
                epg_data[channel].append({
                    'start': programme.get('start'),
                    'stop': programme.get('stop'),
                    'title': programme.find('title').text if programme.find('title') is not None else '',
                    'desc': programme.find('desc').text if programme.find('desc') is not None else ''
                })
        
        log(u'EPG parsed: %d channels, %d programmes' % (len(epg_data), sum(len(p) for p in epg_data.values())))
        return epg_data
        
    except Exception as e:
        log(u'ERROR parsing EPG: %s' % str(e))
        return {}

def generate_xmltv(channels, epg_data, output_file):
    """
    Generate XMLTV file for Kodi PVR
    """
    try:
        log(u'Generating XMLTV: %s' % output_file)
        
        root = ET.Element('tv')
        root.set('generator-info-name', 'Freeview.sk EPG Processor')

        for channel in channels:
            if channel.get('id') and channel.get('name'):
                log(u"Channel %s : %s" % (channel['id'], channel['name']))
                channel_elem = ET.SubElement(root, 'channel')
                channel_elem.set('id', channel['id'])
                display_name = ET.SubElement(channel_elem, 'display-name')
                display_name.text = channel['name']
        
        # Add programmes
        for channel_id, programmes in epg_data.items():
            log(u'Processing %s' % channel_id)
            for prog in programmes:
                programme_elem = ET.SubElement(root, 'programme')
                programme_elem.set('channel', channel_id)
                programme_elem.set('start', prog['start'])
                programme_elem.set('stop', prog['stop'])
                
                title_elem = ET.SubElement(programme_elem, 'title')
                title_elem.text = prog['title']
                
                if prog['desc']:
                    desc_elem = ET.SubElement(programme_elem, 'desc')
                    desc_elem.set('lang', 'cs')
                    desc_elem.text = prog['desc']
        
        # Write XML
        tree = ET.ElementTree(root)
        tree.write(output_file, encoding='utf-8', xml_declaration=True)
        
        log(u'XMLTV generated successfully: %s' % output_file)
        return True
        
    except Exception as e:
        log(u'ERROR generating XMLTV: %s' % str(e))
        traceback.print_exc()
        return False

def update_epg(channels):
    """
    Main function to update EPG
    Called by service.py or manually
    """
    log(u'========================================')
    log(u'EPG UPDATE STARTED')
    log(u'Source: %s' % EPG_URL)
    log(u'========================================')
    
    # Download
    gz_file = download_epg()
    if not gz_file:
        log(u'EPG update FAILED: Download error')
        return False
    
    # Extract
    xml_file = extract_epg(gz_file)
    if not xml_file:
        log(u'EPG update FAILED: Extraction error')
        return False
        
    channel_ids = [i['id'] for i in channels if i.get('id') and i.get('name')]
    
    # Parse
    epg_data = parse_epg(channel_ids, xml_file)
    if not epg_data:
        log(u'EPG update FAILED: Parsing error')
        return False
    
    # Additional epg

    try:
        scrape_tvdoktor(channel_ids, epg_data)
    except Exception as e:
        log(u'ERROR scraping tvdoktor: %s' % str(e))
        traceback.print_exc()

    try:
        scrape_vantagetv(channel_ids, epg_data)
    except Exception as e:
        log(u'ERROR scraping vantagetv: %s' % str(e))
        traceback.print_exc()

    # Generate XMLTV
    output_file = os.path.join(_addon_path, 'epg.xml')
    if not generate_xmltv(channels, epg_data, output_file):
        log(u'EPG update FAILED: Generation error')
        return False
    
    # Cleanup
    try:
        os.remove(gz_file)
        os.remove(xml_file)
    except:
        pass
    
    log(u'========================================')
    log(u'EPG UPDATE COMPLETED SUCCESSFULLY')
    log(u'Output: %s' % output_file)
    log(u'========================================')
    
    return True

# ---------------------------------------------------------------------------
# external epg
# ---------------------------------------------------------------------------

def to_utc_string(dt):
    dt_utc = dt.astimezone(UTC)
    return dt_utc.strftime("%Y%m%d%H%M%S +0000")

# ---------------------------------------------------------------------------
# TV Doktor (https://www.tvdoktor.sk/program/) adopted from "kozmali"
# ---------------------------------------------------------------------------
PURE_TIME_RE = re.compile(r"^(\d{2}):(\d{2})$")
INLINE_TIME_RE = re.compile(r"^(\d{2}):(\d{2})\s*[-:]?\s*(.+)$")

def parse_schedule_lines(lines):
    """Univerzalny parser pre 'HH:MM Nazov' rozvrhy.

    Zvladne DVE rozne situacie, ktore sa v praxi striedaju podla toho,
    ci je cas v rovnakom textovom uzle ako nazov, alebo v samostatnom
    <strong>/<b> tagu (vtedy BeautifulSoup.get_text("\\n") rozdeli
    cas a nazov na dva riadky):
      1) jeden riadok: '05:10 Nazov relacie' / '05:10 - Nazov'
      2) dva riadky:   '05:10' (samotny cas) potom dalsi neprazdny
                        riadok s nazvom

    Vrati zoznam (hh, mm, title) v poradi vystupu.
    """
    results = []
    i, n = 0, len(lines)
    while i < n:
        line = lines[i].strip()
        if not line:
            i += 1
            continue

        m_pure = PURE_TIME_RE.match(line)
        if m_pure:
            hh, mm = int(m_pure.group(1)), int(m_pure.group(2))
            j = i + 1
            title = None
            while j < n:
                nxt = lines[j].strip()
                if not nxt:
                    j += 1
                    continue
                # ak dalsi neprazdny riadok je uz dalsi cas, tento blok
                # je bez nazvu - preskocime ho bez priradenia title
                if PURE_TIME_RE.match(nxt) or INLINE_TIME_RE.match(nxt):
                    break
                title = nxt
                j += 1
                break
            if title:
                results.append((hh, mm, title))
            i = j if title else i + 1
            continue

        m_inline = INLINE_TIME_RE.match(line)
        if m_inline:
            hh, mm, title = m_inline.groups()
            results.append((int(hh), int(mm), title.strip()))

        i += 1
    return results
    
def scrape_tvdoktor(channel_ids, epg_data):
    """TV Doktor ma na jednej stranke realny program na ~7 dni dopredu,
    rozdeleny do tabulek po dnoch s hlavickou 'Nedeľa 28.06.' (bez roku -
    rok si dopocitame podla aktualneho datumu, s rolloverom okolo NY)."""
    programmes = []
    try:
        resp = requests.get("https://www.tvdoktor.sk/program/", headers=HEADERS, timeout=30)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")
        text = soup.get_text("\n")
    except Exception as e:
        log(u'[tvdoktor] chyba pri stahovani: %s' % str(e))
        return

    day_re = re.compile(
        r"(Pondelok|Utorok|Streda|Štvrtok|Piatok|Sobota|Nedeľa)\s+(\d{1,2})\.(\d{1,2})\."
    )

    lines = text.splitlines()
    day_blocks = []
    current_lines = None
    today = datetime.now(TZ).date()

    for line in lines:
        stripped = line.strip()
        m = day_re.match(stripped)
        if m:
            _, d, mo = m.groups()
            day, month = int(d), int(mo)
            year = today.year
            try:
                candidate = datetime(year, month, day).date()
            except ValueError:
                current_lines = None
                continue
            # rocny rollover - ak by datum vysiel viac ako ~2 mesiace v
            # minulosti, je to skor o rok neskor (TV Doktor ukazuje len
            # buduce dni, takze toto riesi hlavne prelom december/januar)
            if (today - candidate).days > 60:
                candidate = datetime(year + 1, month, day).date()
            current_lines = []
            day_blocks.append((candidate, current_lines))
            continue
        if current_lines is not None:
            current_lines.append(line)

    seen_dates = set()
    for day_date, block_lines in day_blocks:
        if day_date in seen_dates:
            continue
        items = parse_schedule_lines(block_lines)
        if not items:
            continue
        seen_dates.add(day_date)
        items = sorted(set(items), key=lambda x: (x[0], x[1]))
        day_dt = datetime(day_date.year, day_date.month, day_date.day, tzinfo=TZ)
        for idx, (hh, mm, title) in enumerate(items):
            start = day_dt.replace(hour=hh, minute=mm)
            if idx + 1 < len(items):
                nh, nm, _ = items[idx + 1]
                stop = day_dt.replace(hour=nh, minute=nm)
                if stop <= start:
                    stop += timedelta(days=1)
            else:
                stop = start + timedelta(hours=1)
            programmes.append({ # append(("TVDOKTOR.sk", start, stop, title))
                    'start': to_utc_string(start),
                    'stop': to_utc_string(stop),
                    'title': title,
                    'desc': ''
            })
    chn_id = 'TVDOKTOR.sk'
    epg_data[chn_id] = programmes

    log(u'[tvdoktor] najdenych %d programov' % len(programmes))
    return programmes

# ---------------------------------------------------------------------------
# Vantage TV (https://vantagetv.eu/epg.xml)
# ---------------------------------------------------------------------------

def scrape_vantagetv(channel_ids, epg_data):
    
    response = requests.get("https://vantagetv.eu/epg.xml", headers=HEADERS, timeout=30)
    response.raise_for_status()
    xml_text = response.text

    vantagetv_epg_data = parse_epg(channel_ids, None, xml_text)
    if not vantagetv_epg_data:
        log(u'[vantagetv] Parsing error')
        return False

    for chn_id, vprog in vantagetv_epg_data.items():
        prog = epg_data.get(chn_id, [])
        if not prog and vprog:
            epg_data[chn_id] = vprog

    log(u'[vantagetv] parsed')
