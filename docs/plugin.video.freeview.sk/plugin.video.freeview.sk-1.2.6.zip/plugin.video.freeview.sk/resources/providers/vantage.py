# -*- coding: utf-8 -*-
# Author: cache-sk
# Created on: 5.7.2026
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import xbmcgui
import xbmcplugin
import requests.cookies

try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode

from utils import setup_adaptive

DATA = 'https://vantagetv.eu/data.php'

HEADERS={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36','referer':'http://live.streaming.sk/'}

def play(_handle, _addon, params):
    
    session = requests.Session()
    session.verify = False
    headers = {}
    headers.update(HEADERS)
    response = session.get(DATA, headers=headers)
    response.raise_for_status()
    data = response.json()
    streams = data['streams']
    channel = next((obj for obj in streams if obj.get("name") == params['channel']), None)
    
    if channel is None:
        raise #TODO

    uheaders = urlencode(HEADERS)

    li = xbmcgui.ListItem(path=channel['url'])
    setup_adaptive(li, None, 'hls')
    xbmcplugin.setResolvedUrl(_handle, True, li)
